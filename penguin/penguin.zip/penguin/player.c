#include <stdio.h>
#include "player.h"

// int give_ID(struct Player player){

// 	printf("%s\n",player.id );
// 	return 0;
// }

// int find_player_position(struct Player player, int  **board, int size[], int how_many_penguins){

// 	int row = size[0];
// 	int col = size[1];
	
// 	for(int p=0; p<how_many_penguins; ++p){

// 		for(int i=0;i<row;++i){

// 			for(int j=0;j<col;++j){

// 				if(board[i][j] == player.player_number )

// 					printf("Your penguin is at coordinates (%d,%d) \n", row, col ); 


// 			}
// 		}
// 	}

// 	return 0;
// }