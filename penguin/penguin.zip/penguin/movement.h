// #include "player.h"

// int check_move(const char *filename, int player_number, int how_many_penguins , int size[], int **board ){

// 	int row = size[0];
// 	int col = saize[1];

// 	for(int i=0; i<row; ++i){

// 		for(int j=0; j<col; ++j){

			
// 		}
// 	}

// }