#pragma once

struct penguin {

    int peng_no;
	int score_of_penguin;
};